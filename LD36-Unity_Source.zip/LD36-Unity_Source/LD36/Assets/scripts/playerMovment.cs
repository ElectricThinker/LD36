﻿using UnityEngine;
using System.Collections;

public class playerMovment : MonoBehaviour {

	public float MaxSpeed = 2;
	public float JumpHeight = 2;
	public LayerMask groundLayer;
	public bool isGrounded;
	public Transform groundCheck;

	private Rigidbody2D rBody;
	private Animator anim;
	private bool facingRight;
	private float groundCheckRadius = 0.2f;



	// Use this for initialization
	void Start () {
		rBody = GetComponent<Rigidbody2D>();
		anim = GetComponent<Animator> ();
		facingRight = true;
		isGrounded = false;

	
	}

	void Update () {

		if (isGrounded && Input.GetAxis ("Jump") > 0) {
			isGrounded = false;
			rBody.AddForce (new Vector2 (0, JumpHeight));
		}
	}

	void FixedUpdate () {

		isGrounded = Physics2D.OverlapCircle (groundCheck.position, groundCheckRadius, groundLayer);





		float inputX = Input.GetAxis ("Horizontal");


		anim.SetFloat ("speed", Mathf.Abs (inputX));
		rBody.velocity = new Vector2 (inputX * MaxSpeed, rBody.velocity.y);
		if (inputX > 0 && !facingRight) {
			flip ();
		} else if (inputX < 0 && facingRight) {
			flip ();
		}

	}

    void flip(){
		facingRight = !facingRight;
		Vector3 scale = transform.localScale;
		scale.x *= -1;
		transform.localScale = scale;
	}
	

}
