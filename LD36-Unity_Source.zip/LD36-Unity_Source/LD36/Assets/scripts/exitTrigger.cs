﻿using UnityEngine;
using System.Collections;

public class exitTrigger : MonoBehaviour {

	public bool Active;
	public int scene = 0;

	// Use this for initialization
	void Start () {
		Active = false;
	}
	void OnTriggerEnter2D(Collider2D other){
		if (other.tag == "Player") {
			Active = true;
		}

	}

	public int getScene(){
		return scene;
	}

	public bool isActive(){
		return Active;
	}

	// Update is called once per frame
	void Update () {

	}
}

