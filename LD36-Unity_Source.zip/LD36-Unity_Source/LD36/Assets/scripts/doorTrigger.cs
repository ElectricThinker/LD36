﻿using UnityEngine;
using System.Collections;

public class doorTrigger : MonoBehaviour {


	public bool Active;

	// Use this for initialization
	void Start () {
		Active = false;
	}
	void OnTriggerEnter2D(Collider2D other){
		if (other.tag == "ball") {
			Active = true;
		}

	}

	public bool isActive(){
		return Active;
	}

	// Update is called once per frame
	void Update () {
	
	}
}
