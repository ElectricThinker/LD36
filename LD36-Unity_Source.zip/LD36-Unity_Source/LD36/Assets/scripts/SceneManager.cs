﻿using UnityEngine;
using System.Collections;

public class SceneManager : MonoBehaviour {

	public exitTrigger trigger;

	bool win;
	//static SceneManager Instance;
	// Use this for initialization
	void Start () {
		win = false;
		/*if (Instance != null) {
			GameObject.Destroy (gameObject);
		} else {
			GameObject.DontDestroyOnLoad (gameObject);
			Instance = this;
		}*/
	
	}
	
	// Update is called once per frame
	void Update () {

		if(Input.GetKeyUp(KeyCode.Escape)){
			Application.Quit();
		}

		if (trigger.isActive() && trigger.getScene() == 0) {
			Application.LoadLevel (1);

		}
		if (trigger.isActive() && trigger.getScene() == 1) {
			Application.LoadLevel (2);
		}

		if (trigger.isActive() && trigger.getScene() == 2) {
			win = true;
			if(Input.GetKeyUp(KeyCode.Return)){
				Application.LoadLevel (0);
			}
		}
	
	}

	public bool hasWon(){
		return win;
	}
}
