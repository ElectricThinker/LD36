﻿using UnityEngine;
using System.Collections;

public class music : MonoBehaviour {


	static music instance;
	// Use this for initialization
	void Start () {
		DontDestroyOnLoad (gameObject);
		if (instance != null) {
			GameObject.Destroy (gameObject);
		} else {
			GameObject.DontDestroyOnLoad (gameObject);
			instance = this;
		}
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
