﻿using UnityEngine;
using System.Collections;

public class text : MonoBehaviour {


	public SceneManager manager;
	public GUIText winText;
	// Use this for initialization
	void Start () {
		winText.text = "";
	
	}
	
	// Update is called once per frame
	void Update () {
	
		if (manager.hasWon ()) {
			winText.text = "You won... or lost! ...idk \n " +
			"Happy Ludum Dare! \n " +
			"\n " +
			"press enter to go back to the begining\n " +
			"or esc to exit\n \n " +
			"made by Electric Thinker";

		}
	}
}
