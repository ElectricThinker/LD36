﻿using UnityEngine;
using System.Collections;

public class door : MonoBehaviour {


	public doorTrigger trigger;
	private Rigidbody2D rBody;


	// Use this for initialization
	void Start () {
		rBody = GetComponent<Rigidbody2D>();

	
	}
	
	// Update is called once per frame
	void FixedUpdate () {

		if (trigger.isActive()) {
			rBody.isKinematic = false;
		} else {
			rBody.isKinematic = true;
		}
	
	}
}
